package com.mybatis3.dao;

public class AddressDaoMain {

	public static void main(String[] args) {
	
		AddressDao addressDao=new AddressDao();
		/*******************AddressDao.findAddressByIdWithStudents()**************/
		System.out.println("---------findAddressByIdWithStudents--------------------");
		System.out.println("---------findAddressByIdWithTutors----------------------");
		
	}

}
